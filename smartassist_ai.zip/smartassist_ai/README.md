# SmartAssist AI — Application Mobile Flutter

Application mobile multilingue avec authentification sécurisée et chatbot IA,
conforme au cahier des charges (ELJANI KARIM).

## ✅ Fonctionnalités implémentées

- Splash Screen animé
- Onboarding (3 écrans)
- Inscription / Connexion (email + mot de passe)
- Connexion Google & Facebook (points d'intégration prêts, voir ci-dessous)
- Double authentification par OTP (code à 6 chiffres)
- Authentification biométrique (empreinte digitale / Face ID) via `local_auth`
- Point d'intégration reconnaissance faciale (ML Kit)
- Gestion du profil (modification nom / téléphone)
- Chatbot IA (réponses simulées + point d'intégration API réelle)
- Interface multilingue Français / Arabe (RTL) / Anglais
- Déconnexion avec confirmation
- Espace Administrateur (gestion des utilisateurs)

## 📂 Structure du projet

```
lib/
 ├─ main.dart                  # Point d'entrée, thème, providers, localisation
 ├─ models/
 │   └─ user_model.dart        # UserModel, ChatMessage
 ├─ providers/
 │   ├─ auth_provider.dart     # Logique d'authentification complète
 │   └─ language_provider.dart # Gestion FR/AR/EN
 ├─ services/
 │   └─ chatbot_service.dart   # Logique du chatbot
 ├─ screens/
 │   ├─ splash_screen.dart
 │   ├─ onboarding_screen.dart
 │   ├─ login_screen.dart
 │   ├─ register_screen.dart
 │   ├─ otp_screen.dart
 │   ├─ biometric_screen.dart
 │   ├─ home_screen.dart
 │   ├─ chatbot_screen.dart
 │   ├─ profile_screen.dart
 │   ├─ settings_screen.dart
 │   ├─ language_screen.dart
 │   └─ admin_screen.dart
 └─ utils/
     ├─ app_theme.dart
     └─ app_translations.dart
```

## 🚀 Installation

1. Installer Flutter (>= 3.0) : https://docs.flutter.dev/get-started/install
2. Récupérer les dépendances :
   ```bash
   flutter pub get
   ```
3. Lancer l'application :
   ```bash
   flutter run
   ```

## 🔌 Points d'intégration à finaliser pour la production

Le projet est **fonctionnel en local** (sans backend) grâce à `SharedPreferences`
pour que tu puisses le tester immédiatement. Pour un déploiement réel, il faut
brancher :

1. **Google Sign-In** (`lib/providers/auth_provider.dart`, méthode `loginWithGoogle`)
   - Configurer Firebase (google-services.json / GoogleService-Info.plist)
   - Décommenter l'appel `GoogleSignIn().signIn()`

2. **Facebook Login** (`loginWithFacebook`)
   - Configurer l'App Facebook (Facebook Developer Console)
   - Utiliser `FacebookAuth.instance.login()`

3. **Envoi réel de l'OTP** (`generateOtp`)
   - Brancher un service backend (Firebase Auth, Twilio, ou API custom)

4. **Reconnaissance faciale / ML Kit** (`biometric_screen.dart`)
   - Ajouter le package `google_ml_kit`
   - Implémenter la capture caméra (package `camera`) + `FaceDetector`

5. **Chatbot IA réel** (`chatbot_service.dart`, méthode `sendToApi`)
   - Brancher une vraie API (Anthropic, OpenAI, Dialogflow...) via `http`

6. **Base de données réelle**
   - Remplacer `SharedPreferences` par Firebase Firestore / une API REST propre

## 🌍 Multilingue

La langue est gérée par `LanguageProvider` avec un système de clés de
traduction (`lib/utils/app_translations.dart`). L'arabe active automatiquement
le mode RTL (`Directionality`).

## 👤 Diagramme de classes (implémenté dans `models/`)

- `UserModel(id, nom, email, langue, telephone, photoUrl, provider, isAdmin)`
- `ChatMessage(text, isUser, timestamp)`
