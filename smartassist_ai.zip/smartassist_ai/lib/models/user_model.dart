/// Modèle Utilisateur — correspond à la classe "Utilisateur" du diagramme
/// de classes : Utilisateur(id, nom, email, langue)
class UserModel {
  final String id;
  String nom;
  String email;
  String langue;
  String? telephone;
  String? photoUrl;
  String provider; // "email", "google", "facebook"
  bool isAdmin;

  UserModel({
    required this.id,
    required this.nom,
    required this.email,
    this.langue = 'fr',
    this.telephone,
    this.photoUrl,
    this.provider = 'email',
    this.isAdmin = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'nom': nom,
        'email': email,
        'langue': langue,
        'telephone': telephone,
        'photoUrl': photoUrl,
        'provider': provider,
        'isAdmin': isAdmin,
      };

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: json['id'],
        nom: json['nom'],
        email: json['email'],
        langue: json['langue'] ?? 'fr',
        telephone: json['telephone'],
        photoUrl: json['photoUrl'],
        provider: json['provider'] ?? 'email',
        isAdmin: json['isAdmin'] ?? false,
      );
}

/// Modèle Message pour le Chatbot IA — Chatbot(message, réponse)
class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;

  ChatMessage({
    required this.text,
    required this.isUser,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();
}
