/// Service Chatbot IA.
///
/// Fournit une logique de réponse basique "hors-ligne" pour que l'app
/// fonctionne sans clé API, et un point d'intégration clair (sendToApi)
/// pour brancher un vrai modèle (ex: Anthropic/OpenAI) via `http`.
class ChatbotService {
  Future<String> getResponse(String userMessage) async {
    // Simule un délai réseau
    await Future.delayed(const Duration(milliseconds: 600));

    final msg = userMessage.toLowerCase().trim();

    if (msg.contains('bonjour') || msg.contains('salut') || msg.contains('hello')) {
      return 'Bonjour ! Je suis SmartAssist, votre assistant intelligent. Comment puis-je vous aider aujourd\'hui ?';
    }
    if (msg.contains('mot de passe') || msg.contains('password')) {
      return 'Pour réinitialiser votre mot de passe, rendez-vous dans "Profil" > "Paramètres de sécurité".';
    }
    if (msg.contains('langue') || msg.contains('language')) {
      return 'Vous pouvez changer la langue de l\'application depuis l\'écran Paramètres > Langue (Français, Arabe, Anglais).';
    }
    if (msg.contains('biométrie') || msg.contains('empreinte') || msg.contains('face')) {
      return 'L\'authentification biométrique utilise votre empreinte digitale ou la reconnaissance faciale pour sécuriser votre connexion.';
    }
    if (msg.contains('merci')) {
      return 'Avec plaisir ! N\'hésitez pas si vous avez d\'autres questions.';
    }

    return 'Je suis encore en apprentissage sur ce sujet, mais je transmets votre question à notre équipe. '
        'En attendant, puis-je vous aider avec votre compte, la sécurité ou les paramètres de l\'application ?';
  }

  /// Point d'intégration pour un vrai modèle d'IA via API.
  /// Exemple d'utilisation avec le package http :
  ///
  /// final response = await http.post(
  ///   Uri.parse('https://api.anthropic.com/v1/messages'),
  ///   headers: {
  ///     'x-api-key': 'VOTRE_CLE_API',
  ///     'anthropic-version': '2023-06-01',
  ///     'content-type': 'application/json',
  ///   },
  ///   body: jsonEncode({
  ///     'model': 'claude-sonnet-4-6',
  ///     'max_tokens': 500,
  ///     'messages': [{'role': 'user', 'content': userMessage}],
  ///   }),
  /// );
  Future<String> sendToApi(String userMessage) async {
    // TODO: implémenter l'appel réel à l'API IA choisie.
    return getResponse(userMessage);
  }
}
