import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/language_provider.dart';
import '../utils/app_theme.dart';

/// Espace Administrateur — correspond au cas d'utilisation "Gérer utilisateurs"
/// et à l'acteur Administrateur(id, nom) du cahier des charges.
class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final usersJson = prefs.getStringList('users') ?? [];
    setState(() {
      _users = usersJson.map((u) => jsonDecode(u) as Map<String, dynamic>).toList();
      _loading = false;
    });
  }

  Future<void> _deleteUser(int index) async {
    final prefs = await SharedPreferences.getInstance();
    final usersJson = prefs.getStringList('users') ?? [];
    usersJson.removeAt(index);
    await prefs.setStringList('users', usersJson);
    _loadUsers();
  }

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LanguageProvider>();
    return Scaffold(
      appBar: AppBar(title: Text(lang.t('admin_panel'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _users.isEmpty
              ? Center(
                  child: Text(
                    'Aucun utilisateur inscrit pour le moment.',
                    style: const TextStyle(color: AppColors.textLight),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _users.length,
                  itemBuilder: (context, index) {
                    final u = _users[index];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFFEDEEF5)),
                      ),
                      child: Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: AppColors.primary.withOpacity(0.1),
                            child: Text(
                              (u['nom'] as String).isNotEmpty
                                  ? (u['nom'] as String)[0].toUpperCase()
                                  : '?',
                              style: const TextStyle(color: AppColors.primary),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(u['nom'] ?? '',
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600)),
                                Text(u['email'] ?? '',
                                    style: const TextStyle(
                                        color: AppColors.textLight,
                                        fontSize: 12)),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline,
                                color: AppColors.error),
                            onPressed: () => _deleteUser(index),
                          ),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}
