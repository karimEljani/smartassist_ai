import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/language_provider.dart';
import '../utils/app_theme.dart';
import 'login_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _editing = false;
  late TextEditingController _nameCtrl;
  late TextEditingController _phoneCtrl;

  @override
  void initState() {
    super.initState();
    final user = context.read<AuthProvider>().currentUser;
    _nameCtrl = TextEditingController(text: user?.nom ?? '');
    _phoneCtrl = TextEditingController(text: user?.telephone ?? '');
  }

  Future<void> _save() async {
    await context.read<AuthProvider>().updateProfile(
          nom: _nameCtrl.text.trim(),
          telephone: _phoneCtrl.text.trim(),
        );
    setState(() => _editing = false);
  }

  Future<void> _logout() async {
    final lang = context.read<LanguageProvider>();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(lang.t('logout')),
        content: Text(lang.t('logout_confirm')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(lang.t('cancel'))),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(lang.t('logout'),
                  style: const TextStyle(color: AppColors.error))),
        ],
      ),
    );
    if (confirmed == true) {
      await context.read<AuthProvider>().logout();
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LanguageProvider>();
    final user = context.watch<AuthProvider>().currentUser;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(lang.t('profile'),
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.bold)),
              IconButton(
                icon: Icon(_editing ? Icons.close : Icons.edit_outlined),
                onPressed: () => setState(() => _editing = !_editing),
              ),
            ],
          ),
          const SizedBox(height: 20),
          CircleAvatar(
            radius: 48,
            backgroundColor: AppColors.primary.withOpacity(0.1),
            child: Text(
              (user?.nom.isNotEmpty == true ? user!.nom[0] : '?').toUpperCase(),
              style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primary),
            ),
          ),
          const SizedBox(height: 20),
          if (!_editing) ...[
            Text(user?.nom ?? '',
                style: const TextStyle(
                    fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(user?.email ?? '',
                style: const TextStyle(color: AppColors.textLight)),
            const SizedBox(height: 24),
            _infoTile(Icons.phone_outlined, lang.t('phone'),
                user?.telephone?.isNotEmpty == true ? user!.telephone! : '—'),
            _infoTile(Icons.verified_user_outlined, 'Provider',
                user?.provider ?? 'email'),
            _infoTile(Icons.language, lang.t('language'), user?.langue ?? 'fr'),
          ] else ...[
            TextField(
              controller: _nameCtrl,
              decoration: InputDecoration(labelText: lang.t('full_name')),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(labelText: lang.t('phone')),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _save, child: Text(lang.t('save'))),
          ],
          const SizedBox(height: 32),
          OutlinedButton.icon(
            onPressed: _logout,
            icon: const Icon(Icons.logout, color: AppColors.error),
            label: Text(lang.t('logout'),
                style: const TextStyle(color: AppColors.error)),
            style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.error)),
          ),
        ],
      ),
    );
  }

  Widget _infoTile(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFEDEEF5)),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppColors.primary, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        fontSize: 12, color: AppColors.textLight)),
                Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
