import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/language_provider.dart';
import '../utils/app_theme.dart';
import 'home_screen.dart';

/// Écran regroupant l'authentification biométrique (empreinte digitale)
/// et le point d'entrée pour la reconnaissance faciale (ML Kit Face Detection).
class BiometricScreen extends StatefulWidget {
  const BiometricScreen({super.key});

  @override
  State<BiometricScreen> createState() => _BiometricScreenState();
}

class _BiometricScreenState extends State<BiometricScreen> {
  bool _loading = false;
  String? _statusMessage;

  Future<void> _authenticate() async {
    setState(() {
      _loading = true;
      _statusMessage = null;
    });
    final auth = context.read<AuthProvider>();
    final canUse = await auth.canUseBiometrics();

    if (!canUse) {
      setState(() {
        _loading = false;
        _statusMessage =
            'La biométrie n\'est pas disponible/configurée sur cet appareil.';
      });
      return;
    }

    final error = await auth.authenticateWithBiometrics();
    setState(() => _loading = false);

    if (!mounted) return;
    if (error != null) {
      setState(() => _statusMessage = error);
    } else {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LanguageProvider>();
    return Scaffold(
      appBar: AppBar(title: Text(lang.t('biometric_auth'))),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              GestureDetector(
                onTap: _loading ? null : _authenticate,
                child: Container(
                  width: 140,
                  height: 140,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: _loading
                      ? const Padding(
                          padding: EdgeInsets.all(40),
                          child: CircularProgressIndicator(),
                        )
                      : const Icon(Icons.fingerprint,
                          size: 72, color: AppColors.primary),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Touchez pour vous authentifier',
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Text(
                'Empreinte digitale ou Face ID selon votre appareil',
                style: const TextStyle(color: AppColors.textLight),
                textAlign: TextAlign.center,
              ),
              if (_statusMessage != null) ...[
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.error.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    _statusMessage!,
                    style: const TextStyle(color: AppColors.error),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
              const SizedBox(height: 32),
              OutlinedButton.icon(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                          'Reconnaissance faciale : intégrer google_ml_kit '
                          '(Face Detection) + CameraX pour la capture en direct.'),
                    ),
                  );
                },
                icon: const Icon(Icons.face_retouching_natural,
                    color: AppColors.primary),
                label: Text(lang.t('face_recognition')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
