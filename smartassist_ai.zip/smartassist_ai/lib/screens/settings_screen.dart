import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/language_provider.dart';
import '../utils/app_theme.dart';
import 'language_screen.dart';
import 'admin_screen.dart';
import 'biometric_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LanguageProvider>();
    final user = context.watch<AuthProvider>().currentUser;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(lang.t('settings'),
              style:
                  const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          _settingsTile(
            context,
            icon: Icons.language,
            title: lang.t('language'),
            subtitle: lang.currentLang.toUpperCase(),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const LanguageScreen()),
            ),
          ),
          _settingsTile(
            context,
            icon: Icons.fingerprint,
            title: lang.t('biometric_auth'),
            subtitle: 'Configurer l\'accès rapide',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const BiometricScreen()),
            ),
          ),
          if (user?.isAdmin == true)
            _settingsTile(
              context,
              icon: Icons.admin_panel_settings_outlined,
              title: lang.t('admin_panel'),
              subtitle: lang.t('manage_users'),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const AdminScreen()),
              ),
            ),
          _settingsTile(
            context,
            icon: Icons.info_outline,
            title: 'À propos',
            subtitle: 'SmartAssist AI v1.0.0',
            onTap: () {},
          ),
        ],
      ),
    );
  }

  Widget _settingsTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFEDEEF5)),
      ),
      child: ListTile(
        leading: Icon(icon, color: AppColors.primary),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right, color: AppColors.textLight),
        onTap: onTap,
      ),
    );
  }
}
