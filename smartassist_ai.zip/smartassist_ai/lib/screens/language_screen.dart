import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/language_provider.dart';
import '../utils/app_theme.dart';

class LanguageScreen extends StatelessWidget {
  const LanguageScreen({super.key});

  static const _languages = [
    {'code': 'fr', 'label': 'Français', 'flag': '🇫🇷'},
    {'code': 'en', 'label': 'English', 'flag': '🇬🇧'},
    {'code': 'ar', 'label': 'العربية', 'flag': '🇹🇳'},
  ];

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LanguageProvider>();
    return Scaffold(
      appBar: AppBar(title: Text(lang.t('choose_language'))),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _languages.length,
        itemBuilder: (context, index) {
          final item = _languages[index];
          final selected = lang.currentLang == item['code'];
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: selected ? AppColors.primary : const Color(0xFFEDEEF5),
                width: selected ? 1.5 : 1,
              ),
            ),
            child: ListTile(
              leading: Text(item['flag']!, style: const TextStyle(fontSize: 24)),
              title: Text(item['label']!,
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              trailing: selected
                  ? const Icon(Icons.check_circle, color: AppColors.primary)
                  : null,
              onTap: () => context
                  .read<LanguageProvider>()
                  .changeLanguage(item['code']!),
            ),
          );
        },
      ),
    );
  }
}
