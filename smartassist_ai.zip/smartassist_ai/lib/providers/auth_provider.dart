import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';

/// Gère tout le cycle d'authentification :
/// - Inscription / Connexion classique (email + mot de passe)
/// - Connexion Google / Facebook (points d'intégration prêts)
/// - Double authentification OTP
/// - Authentification biométrique (empreinte digitale / Face ID)
///
/// NOTE : la persistance "backend" est simulée en local (SharedPreferences)
/// afin que le projet soit exécutable sans serveur. Il suffit de brancher
/// de vrais appels API dans les méthodes marquées TODO pour un usage réel.
class AuthProvider extends ChangeNotifier {
  UserModel? _currentUser;
  String? _pendingOtp;
  String? _pendingEmail;
  final LocalAuthentication _localAuth = LocalAuthentication();

  UserModel? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;

  /// -------------------- INSCRIPTION --------------------
  Future<String?> register({
    required String nom,
    required String email,
    required String password,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final usersJson = prefs.getStringList('users') ?? [];

    // Vérifie si l'email existe déjà
    for (final u in usersJson) {
      final map = jsonDecode(u);
      if (map['email'] == email) {
        return 'Un compte existe déjà avec cet e-mail.';
      }
    }

    final newUser = UserModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      nom: nom,
      email: email,
      provider: 'email',
    );

    usersJson.add(jsonEncode({...newUser.toJson(), 'password': password}));
    await prefs.setStringList('users', usersJson);

    // TODO: remplacer par un vrai appel API d'inscription
    return null; // null = succès
  }

  /// -------------------- CONNEXION EMAIL / MOT DE PASSE --------------------
  Future<String?> login({
    required String email,
    required String password,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final usersJson = prefs.getStringList('users') ?? [];

    for (final u in usersJson) {
      final map = jsonDecode(u);
      if (map['email'] == email && map['password'] == password) {
        _pendingEmail = email;
        generateOtp(); // Déclenche la double authentification OTP
        notifyListeners();
        return null;
      }
    }
    return 'E-mail ou mot de passe incorrect.';
  }

  /// -------------------- CONNEXION GOOGLE --------------------
  /// Point d'intégration : brancher le package `google_sign_in`.
  /// Nécessite la configuration Firebase (google-services.json / plist).
  Future<String?> loginWithGoogle() async {
    try {
      // TODO: intégrer GoogleSignIn().signIn() ici
      // final googleUser = await GoogleSignIn().signIn();
      // final googleAuth = await googleUser?.authentication;
      final simulatedUser = UserModel(
        id: 'google_${DateTime.now().millisecondsSinceEpoch}',
        nom: 'Utilisateur Google',
        email: 'utilisateur.google@gmail.com',
        provider: 'google',
      );
      await _persistSession(simulatedUser);
      return null;
    } catch (e) {
      return 'Échec de la connexion Google : $e';
    }
  }

  /// -------------------- CONNEXION FACEBOOK --------------------
  /// Point d'intégration : brancher le package `flutter_facebook_auth`.
  Future<String?> loginWithFacebook() async {
    try {
      // TODO: intégrer FacebookAuth.instance.login() ici
      final simulatedUser = UserModel(
        id: 'facebook_${DateTime.now().millisecondsSinceEpoch}',
        nom: 'Utilisateur Facebook',
        email: 'utilisateur.facebook@example.com',
        provider: 'facebook',
      );
      await _persistSession(simulatedUser);
      return null;
    } catch (e) {
      return 'Échec de la connexion Facebook : $e';
    }
  }

  /// -------------------- OTP --------------------
  String generateOtp() {
    final otp = (100000 + Random().nextInt(900000)).toString();
    _pendingOtp = otp;
    // TODO: envoyer l'OTP réel par e-mail/SMS via un service backend
    debugPrint('OTP généré (simulation) : $otp');
    return otp;
  }

  Future<String?> verifyOtp(String code) async {
    if (code == _pendingOtp) {
      final prefs = await SharedPreferences.getInstance();
      final usersJson = prefs.getStringList('users') ?? [];
      for (final u in usersJson) {
        final map = jsonDecode(u);
        if (map['email'] == _pendingEmail) {
          final user = UserModel.fromJson(map);
          await _persistSession(user);
          return null;
        }
      }
      return 'Utilisateur introuvable.';
    }
    return 'Code OTP invalide.';
  }

  /// -------------------- AUTHENTIFICATION BIOMÉTRIQUE --------------------
  Future<bool> canUseBiometrics() async {
    try {
      final canCheck = await _localAuth.canCheckBiometrics;
      final isSupported = await _localAuth.isDeviceSupported();
      return canCheck && isSupported;
    } catch (_) {
      return false;
    }
  }

  Future<String?> authenticateWithBiometrics() async {
    try {
      final didAuthenticate = await _localAuth.authenticate(
        localizedReason:
            'Authentifiez-vous avec votre empreinte digitale ou Face ID',
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );
      if (didAuthenticate) {
        final prefs = await SharedPreferences.getInstance();
        final savedUserJson = prefs.getString('last_session_user');
        if (savedUserJson != null) {
          await _persistSession(UserModel.fromJson(jsonDecode(savedUserJson)));
          return null;
        }
        return 'Aucune session précédente trouvée. Connectez-vous une première fois.';
      }
      return 'Authentification biométrique annulée.';
    } catch (e) {
      return 'Biométrie indisponible sur cet appareil : $e';
    }
  }

  /// -------------------- SESSION --------------------
  Future<void> _persistSession(UserModel user) async {
    _currentUser = user;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('last_session_user', jsonEncode(user.toJson()));
    notifyListeners();
  }

  Future<void> updateProfile({
    String? nom,
    String? telephone,
    String? langue,
  }) async {
    if (_currentUser == null) return;
    if (nom != null) _currentUser!.nom = nom;
    if (telephone != null) _currentUser!.telephone = telephone;
    if (langue != null) _currentUser!.langue = langue;
    await _persistSession(_currentUser!);
  }

  Future<void> logout() async {
    _currentUser = null;
    notifyListeners();
  }

  /// Restaure une session existante au démarrage (Splash Screen)
  Future<bool> tryRestoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUserJson = prefs.getString('current_session');
    if (savedUserJson != null) {
      _currentUser = UserModel.fromJson(jsonDecode(savedUserJson));
      notifyListeners();
      return true;
    }
    return false;
  }
}
