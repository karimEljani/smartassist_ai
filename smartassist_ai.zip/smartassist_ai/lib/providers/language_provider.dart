import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/app_translations.dart';

/// Gère la langue courante de l'application (FR / AR / EN)
/// et fournit la méthode t() pour traduire une clé.
class LanguageProvider extends ChangeNotifier {
  String _currentLang = 'fr';

  String get currentLang => _currentLang;

  bool get isRtl => _currentLang == 'ar';

  TextDirection get textDirection =>
      isRtl ? TextDirection.rtl : TextDirection.ltr;

  LanguageProvider() {
    _loadLanguage();
  }

  Future<void> _loadLanguage() async {
    final prefs = await SharedPreferences.getInstance();
    _currentLang = prefs.getString('app_language') ?? 'fr';
    notifyListeners();
  }

  Future<void> changeLanguage(String langCode) async {
    _currentLang = langCode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app_language', langCode);
    notifyListeners();
  }

  /// Traduit une clé selon la langue active. Retourne la clé si absente.
  String t(String key) {
    return AppTranslations.values[_currentLang]?[key] ??
        AppTranslations.values['fr']?[key] ??
        key;
  }
}
